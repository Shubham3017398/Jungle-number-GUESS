import tkinter as tk
from tkinter import messagebox
import random
import os
import pygame  # Ensure you ran: pip install pygame

class JungleGame:
    def __init__(self, root):
        self.root = root
        self.root.title("Jungle Guess: Survival")
        self.root.geometry("500x800")
        self.root.configure(bg="#0b1a0e")

        # --- AUDIO INITIALIZATION ---
        pygame.mixer.init()
        script_dir = os.path.dirname(os.path.abspath(__file__))
        
        music_file = "hitslab-game-gaming-music-295075.mp3"
        click_file = "mixkit-handgun-click-1660.mp3"
        
        music_path = os.path.join(script_dir, music_file)
        click_path = os.path.join(script_dir, click_file)

        # Background Music
        try:
            if os.path.exists(music_path):
                pygame.mixer.music.load(music_path)
                pygame.mixer.music.set_volume(0.5)
                pygame.mixer.music.play(-1)
        except: pass

        # Pre-load Click Sound for zero-latency
        self.click_sfx = None
        try:
            if os.path.exists(click_path):
                self.click_sfx = pygame.mixer.Sound(click_path)
        except: pass

        # --- Game State ---
        self.modes = {"Easy": (10, 5), "Medium": (100, 7), "Hard": (500, 10)}
        self.difficulty = tk.StringVar(value="Medium")
        self.volume = tk.DoubleVar(value=0.5)
        self.graphics = tk.IntVar(value=2)
        
        self.main_container = tk.Frame(root, bg="#0b1a0e")
        self.main_container.pack(fill="both", expand=True)

        self.frames = {}
        for F in (MainMenu, GamePage, SoundPage, SettingsPage):
            page_name = F.__name__
            frame = F(parent=self.main_container, controller=self)
            self.frames[page_name] = frame
            frame.grid(row=0, column=0, sticky="nsew")

        self.main_container.grid_rowconfigure(0, weight=1)
        self.main_container.grid_columnconfigure(0, weight=1)

        # --- THE FIX: ADD="+" ---
        # Using add="+" ensures the sound plays AND the button command still works.
        self.root.bind_class("Button", "<Button-1>", lambda e: self.play_click_sfx(), add="+")

        self.show_frame("MainMenu")

    def play_click_sfx(self):
        if self.click_sfx:
            self.click_sfx.play()

    def update_volume(self, val):
        pygame.mixer.music.set_volume(float(val))
        if self.click_sfx:
            self.click_sfx.set_volume(float(val))

    def show_frame(self, page_name):
        frame = self.frames[page_name]
        frame.tkraise()
        if page_name == "GamePage":
            mode = self.difficulty.get()
            self.max_val, self.lives = self.modes[mode]
            self.secret_number = random.randint(1, self.max_val)
            frame.prepare_ui()

# --- ALL OTHER CLASSES REMAIN EXACTLY AS YOUR ORIGINAL CODE ---

class MainMenu(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg="#0b1a0e")
        self.controller = controller
        content = tk.Frame(self, bg="#0b1a0e")
        content.place(relx=0.5, rely=0.5, anchor="center")
        tk.Label(content, text="🌿 JUNGLE GUESS 🌿", font=("Impact", 40), bg="#0b1a0e", fg="#a2d149").pack(pady=20)
        self.btn_group = tk.Frame(content, bg="#0b1a0e")
        self.btn_group.pack()
        btn_style = {"font": ("Arial", 14, "bold"), "bg": "#3e2723", "fg": "#d7ccc8", "width": 18, "bd": 5, "relief": "raised", "pady": 10}
        tk.Button(self.btn_group, text="🪨 PLAY", command=self.show_levels, **btn_style).pack(pady=8)
        tk.Button(self.btn_group, text="🔊 SOUND", command=lambda: controller.show_frame("SoundPage"), **btn_style).pack(pady=8)
        tk.Button(self.btn_group, text="⚙️ SETTINGS", command=lambda: controller.show_frame("SettingsPage"), **btn_style).pack(pady=8)
        tk.Button(self.btn_group, text="🚪 LEAVE JUNGLE", command=self.exit_app, font=("Arial", 14, "bold"), bg="#1a0f0e", fg="#ff5252", width=18, bd=5, relief="raised", pady=10).pack(pady=20)
        self.level_frame = tk.Frame(content, bg="#0b1a0e")
        tk.Label(self.level_frame, text="SELECT DIFFICULTY", fg="#f0f4c3", bg="#0b1a0e", font=("Impact", 20)).pack(pady=15)
        for m in ["Easy", "Medium", "Hard"]:
            tk.Button(self.level_frame, text=m, bg="#2e7d32", fg="white", width=15, font=("Arial", 11, "bold"), command=lambda mode=m: self.start_game(mode)).pack(pady=5)
        tk.Button(self.level_frame, text="⬅ BACK TO CAMP", bg="#3e2723", fg="white", font=("Arial", 10, "bold"), command=self.hide_levels).pack(pady=20)

    def show_levels(self):
        self.btn_group.pack_forget()
        self.level_frame.pack()

    def hide_levels(self):
        self.level_frame.pack_forget()
        self.btn_group.pack()

    def exit_app(self):
        if messagebox.askokcancel("Exit", "Do you want to close the game?"):
            self.controller.root.destroy()

    def start_game(self, mode):
        self.controller.difficulty.set(mode)
        self.hide_levels()
        self.controller.show_frame("GamePage")

class GamePage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg="#1b2e1f")
        self.controller = controller
        self.is_game_over = False
        self.exit_btn = tk.Button(self, text="✖ EXIT", font=("Arial", 9, "bold"), bg="#3e2723", fg="#ff5252", command=self.confirm_exit, relief="flat", padx=10)
        self.exit_btn.place(x=10, y=10)
        content = tk.Frame(self, bg="#1b2e1f")
        content.place(relx=0.5, rely=0.5, anchor="center")
        self.canvas = tk.Canvas(content, width=400, height=200, bg="#1b2e1f", highlightthickness=0)
        self.canvas.pack()
        self.lives_lbl = tk.Label(content, text="", font=("Impact", 30), bg="#1b2e1f", fg="#ff7043")
        self.lives_lbl.pack()
        self.entry = tk.Entry(content, font=("Impact", 50), justify='center', width=5, bg="#0b1a0e", fg="#a2d149", bd=3, relief="solid")
        self.entry.pack(pady=20)
        self.entry.bind('<Return>', lambda e: self.check_guess())
        self.submit_btn = tk.Button(content, text="SUBMIT GUESS", command=self.check_guess, bg="#a2d149", fg="#0b1a0e", font=("Arial", 14, "bold"), width=20)
        self.submit_btn.pack()
        self.feedback = tk.Label(content, text="", font=("Arial", 15, "bold"), bg="#1b2e1f", fg="#f0f4c3")
        self.feedback.pack(pady=30)

    def confirm_exit(self):
        if messagebox.askyesno("Jungle Alert", "Are you sure?"):
            self.controller.show_frame("MainMenu")

    def prepare_ui(self):
        self.is_game_over = False
        self.submit_btn.config(state="normal")
        self.entry.config(state="normal")
        self.entry.delete(0, tk.END)
        self.lives_lbl.config(text=f"❤️ {self.controller.lives} LIVES")
        self.feedback.config(text=f"Find the number: 1 to {self.controller.max_val}", fg="#f0f4c3")
        self.canvas.delete("all")

    def check_guess(self):
        if self.is_game_over: return
        try:
            val = int(self.entry.get())
            self.controller.lives -= 1
            self.entry.delete(0, tk.END)
            if val == self.controller.secret_number:
                self.end_sequence("WIN")
            elif self.controller.lives <= 0:
                self.end_sequence("LOSE")
            elif val < self.controller.secret_number:
                self.feedback.config(text="TOO LOW! 🐾", fg="#81d4fa")
            else:
                self.feedback.config(text="TOO HIGH! 🦅", fg="#ef5350")
            self.lives_lbl.config(text=f"❤️ {self.controller.lives} LIVES")
        except: pass

    def end_sequence(self, status):
        self.is_game_over = True
        self.submit_btn.config(state="disabled")
        self.entry.config(state="disabled")
        if status == "WIN":
            self.feedback.config(text="CORRECT! 🏆", fg="#a2d149")
            self.high_quality_firework()
        else:
            self.feedback.config(text=f"BOOM! IT WAS {self.controller.secret_number} 💥", fg="#ff5252")
            self.high_quality_explosion()
        self.controller.root.after(4000, lambda: self.controller.show_frame("MainMenu"))

    def high_quality_firework(self):
        colors = ["#FFD700", "#FF4500", "#ADFF2F", "#00FFFF", "#FF00FF"]
        for _ in range(12):
            x, y = random.randint(100, 300), random.randint(50, 150)
            c = random.choice(colors)
            for _ in range(12):
                p = self.canvas.create_oval(x, y, x+4, y+4, fill=c, outline="")
                self.animate_particle(p, random.uniform(-7, 7), random.uniform(-7, 7))

    def animate_particle(self, p, dx, dy, life=0):
        if life < 25:
            self.canvas.move(p, dx, dy)
            self.controller.root.after(30, lambda: self.animate_particle(p, dx, dy + 0.4, life+1))
        else: self.canvas.delete(p)

    def high_quality_explosion(self):
        x, y = 200, 100
        exp = self.canvas.create_oval(x-5, y-5, x+5, y+5, fill="#ffcc00", outline="#ffffff")
        def grow(size):
            if size < 200:
                self.canvas.coords(exp, x-size, y-size, x+size, y+size)
                color = "#ff4400" if size > 80 else "#ffcc00"
                self.canvas.itemconfig(exp, fill=color)
                self.controller.root.after(10, lambda: grow(size+15))
            else: self.canvas.delete(exp)
        grow(5)

class SoundPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg="#0b1a0e")
        content = tk.Frame(self, bg="#0b1a0e")
        content.place(relx=0.5, rely=0.5, anchor="center")
        tk.Label(content, text="🔊 SOUND VINE", font=("Impact", 35), bg="#0b1a0e", fg="#a2d149").pack(pady=20)
        tk.Label(content, text="ADJUST VOLUME", bg="#0b1a0e", fg="white", font=("Arial", 11, "bold")).pack()
        tk.Scale(content, from_=0, to=1, resolution=0.1, orient=tk.HORIZONTAL, variable=controller.volume, command=controller.update_volume, bg="#0b1a0e", fg="#a2d149", troughcolor="#3e2723", length=320, bd=0).pack(pady=30)
        tk.Button(content, text="RETURN TO CAMP", command=lambda: controller.show_frame("MainMenu"), bg="#3e2723", fg="white", font=("Arial", 12, "bold"), width=20, pady=10).pack(pady=40)

class SettingsPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent, bg="#0b1a0e")
        content = tk.Frame(self, bg="#0b1a0e")
        content.place(relx=0.5, rely=0.5, anchor="center")
        tk.Label(content, text="⚙️ GRAPHIC SETTINGS", font=("Impact", 35), bg="#0b1a0e", fg="#a2d149").pack(pady=20)
        tk.Label(content, text="JUNGLE DENSITY", bg="#0b1a0e", fg="white", font=("Arial", 11, "bold")).pack(pady=10)
        g_frame = tk.Frame(content, bg="#0b1a0e")
        g_frame.pack()
        for txt, v in [("LOW", 1), ("MED", 2), ("ULTRA", 3)]:
            tk.Radiobutton(g_frame, text=txt, variable=controller.graphics, value=v, indicatoron=0, width=10, bg="#1b2e1f", fg="#a2d149", selectcolor="#2e7d32").pack(side=tk.LEFT, padx=5, pady=20)
        tk.Button(content, text="RETURN TO CAMP", command=lambda: controller.show_frame("MainMenu"), bg="#3e2723", fg="white", font=("Arial", 12, "bold"), width=20, pady=10).pack(pady=40)

if __name__ == "__main__":
    root = tk.Tk()
    game = JungleGame(root)
    root.mainloop()